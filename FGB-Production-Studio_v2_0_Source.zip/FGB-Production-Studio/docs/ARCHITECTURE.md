# Architecture

## App shell
Electron provides desktop access, native dialogs, and future access to bundled rendering tools.

## Interface
React + TypeScript controls the production screen state.

## Data
Initial version uses in-app state. Later versions should persist to local JSON or SQLite.

## Rendering
The render API is wired through Electron IPC. v2.1 should connect it to bundled FFmpeg.

## Projects
Projects are not separate apps. They are configurations:

- Football's Greatest Bears
- Football's Greatest Bars
- EPIC Communities
