# FGB Production Studio Roadmap

## v2.0
- Clean Electron + React foundation
- Working presets
- Visibility controls
- Project switching
- Countdown preview

## v2.1
- Bundle FFmpeg
- Make Render MP4 functional
- Add render progress

## v2.2
- QR Library
- Default EPIC Communities QR
- Community Partner QR presets

## v2.3
- Community Partner database

## v2.4
- Episode Manager

## v2.5
- Teleprompter

## v2.6
- Thumbnail Builder

## v3.0
- Full Windows app release
