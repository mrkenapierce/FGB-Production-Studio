# GitHub Setup

The connected GitHub account did not show any installed/accessible repositories through the GitHub connector.

To publish this project:

1. Create a GitHub repository named `FGB-Production-Studio`.
2. Upload the contents of this ZIP, or run:

```bash
git init
git add .
git commit -m "Initial FGB Production Studio 2.0 scaffold"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/FGB-Production-Studio.git
git push -u origin main
```

After the repo exists and the GitHub connector can access it, future updates can be pushed through GitHub workflows.
