import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import path from 'node:path';
import { spawn } from 'node:child_process';

const isDev = process.env.NODE_ENV === 'development';

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    backgroundColor: '#031226',
    webPreferences: {
      preload: path.join(__dirname, '../preload/preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  if (isDev) {
    win.loadURL('http://127.0.0.1:5173');
  } else {
    win.loadFile(path.join(__dirname, '../renderer/index.html'));
  }
}

app.whenReady().then(createWindow);

ipcMain.handle('render-countdown', async (_event, payload) => {
  const save = await dialog.showSaveDialog({
    title: 'Save countdown MP4',
    defaultPath: payload.defaultName || 'countdown.mp4',
    filters: [{ name: 'MP4 Video', extensions: ['mp4'] }]
  });

  if (save.canceled || !save.filePath) {
    return { ok: false, canceled: true };
  }

  // v2.0 placeholder: this will call the bundled renderer in v2.1.
  // For now it returns the intended save path and render settings.
  return {
    ok: true,
    path: save.filePath,
    settings: payload,
    note: 'Renderer hook ready. FFmpeg bundling is the next implementation step.'
  };
});
