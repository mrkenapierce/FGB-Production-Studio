import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('fgbStudio', {
  renderCountdown: (payload: unknown) => ipcRenderer.invoke('render-countdown', payload)
});
