export type ProjectKey = 'fgb' | 'fgbars' | 'epic-communities';

export const projects = {
  fgb: {
    label: "Football's Greatest Bears",
    shortLabel: 'FGB',
    primaryColor: '#f15a24',
    background: '#031226',
    defaultQr: 'epic-communities'
  },
  fgbars: {
    label: "Football's Greatest Bars",
    shortLabel: 'FGBars',
    primaryColor: '#f15a24',
    background: '#031226',
    defaultQr: 'epic-communities'
  },
  'epic-communities': {
    label: 'EPIC Communities',
    shortLabel: 'EPIC',
    primaryColor: '#f15a24',
    background: '#031226',
    defaultQr: 'epic-communities'
  }
} as const;
