export type PresetName =
  | 'minimal'
  | 'standard'
  | 'countdown'
  | 'communityPartner'
  | 'sponsorSpotlight'
  | 'fullBroadcast';

export const presets = {
  minimal: {
    label: 'Minimal',
    visible: ['timer', 'qr', 'branding']
  },
  standard: {
    label: 'Standard',
    visible: ['episodeLine', 'timer', 'status', 'progress', 'qr', 'branding']
  },
  countdown: {
    label: 'Countdown Only',
    visible: ['timer', 'status', 'progress']
  },
  communityPartner: {
    label: 'Community Partner',
    visible: ['episodeLine', 'timer', 'status', 'progress', 'partner', 'partnerFields', 'grantBadge', 'qr', 'branding']
  },
  sponsorSpotlight: {
    label: 'Sponsor Spotlight',
    visible: ['timer', 'partner', 'partnerFields', 'grantBadge', 'qr', 'branding']
  },
  fullBroadcast: {
    label: 'Full Broadcast',
    visible: ['episodeLine', 'timer', 'status', 'progress', 'partner', 'partnerFields', 'grantBadge', 'qr', 'branding']
  }
} as const;
