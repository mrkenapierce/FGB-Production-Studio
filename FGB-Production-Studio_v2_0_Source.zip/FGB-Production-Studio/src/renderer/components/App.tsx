import { useEffect, useMemo, useState } from 'react';
import { projects, ProjectKey } from '../data/projects';
import { presets, PresetName } from '../data/presets';
import { formatClock } from '../lib/format';

type VisibleKey =
  | 'episodeLine'
  | 'timer'
  | 'status'
  | 'progress'
  | 'partner'
  | 'partnerFields'
  | 'grantBadge'
  | 'qr'
  | 'branding';

const allVisibleKeys: VisibleKey[] = [
  'episodeLine',
  'timer',
  'status',
  'progress',
  'partner',
  'partnerFields',
  'grantBadge',
  'qr',
  'branding'
];

export function App() {
  const [projectKey, setProjectKey] = useState<ProjectKey>('fgb');
  const [presetName, setPresetName] = useState<PresetName>('standard');
  const [visible, setVisible] = useState<Record<VisibleKey, boolean>>(() => {
    const initial = Object.fromEntries(allVisibleKeys.map(k => [k, false])) as Record<VisibleKey, boolean>;
    presets.standard.visible.forEach(k => { initial[k as VisibleKey] = true; });
    return initial;
  });

  const [durationMinutes, setDurationMinutes] = useState(15);
  const [remaining, setRemaining] = useState(15 * 60);
  const [running, setRunning] = useState(false);

  const [episodeNumber, setEpisodeNumber] = useState('001');
  const [episodeTitle, setEpisodeTitle] = useState('Episode Title');
  const [business, setBusiness] = useState('Your Business Name');
  const [location, setLocation] = useState('Your City, Your State');
  const [contact, setContact] = useState('Website • Phone • Social');
  const [promotion, setPromotion] = useState('Community Partner Promotion');

  const project = projects[projectKey];

  function applyPreset(next: PresetName) {
    setPresetName(next);
    const fresh = Object.fromEntries(allVisibleKeys.map(k => [k, false])) as Record<VisibleKey, boolean>;
    presets[next].visible.forEach(k => { fresh[k as VisibleKey] = true; });
    setVisible(fresh);
  }

  function toggle(key: VisibleKey) {
    setVisible(current => ({ ...current, [key]: !current[key] }));
  }

  function resetCountdown() {
    setRunning(false);
    setRemaining(durationMinutes * 60);
  }

  async function renderCountdown() {
    const api = (window as any).fgbStudio;
    if (!api?.renderCountdown) {
      alert('Render hook is available only in the desktop app. Browser preview cannot render MP4 directly.');
      return;
    }
    const defaultName = `${project.shortLabel}_Ep${episodeNumber}_Countdown.mp4`;
    const result = await api.renderCountdown({
      project: projectKey,
      mode: projectKey,
      minutes: durationMinutes,
      episode: episodeNumber,
      title: episodeTitle,
      defaultName
    });
    if (result?.ok) {
      alert(`Render request prepared: ${result.path}`);
    }
  }

  useEffect(() => {
    setRemaining(durationMinutes * 60);
  }, [durationMinutes]);

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      setRemaining(current => {
        if (current <= 1) {
          setRunning(false);
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [running]);

  const progress = useMemo(() => {
    const duration = durationMinutes * 60;
    if (!duration) return 0;
    return Math.min(100, Math.max(0, ((duration - remaining) / duration) * 100));
  }, [durationMinutes, remaining]);

  return (
    <main className="studio">
      <aside className="controls">
        <h1>FGB Production Studio 2.0</h1>

        <label>Project</label>
        <select value={projectKey} onChange={e => setProjectKey(e.target.value as ProjectKey)}>
          {Object.entries(projects).map(([key, value]) => (
            <option key={key} value={key}>{value.label}</option>
          ))}
        </select>

        <label>Preset</label>
        <select value={presetName} onChange={e => applyPreset(e.target.value as PresetName)}>
          {Object.entries(presets).map(([key, value]) => (
            <option key={key} value={key}>{value.label}</option>
          ))}
        </select>

        <label>Duration Minutes</label>
        <input type="number" min={1} max={120} value={durationMinutes} onChange={e => setDurationMinutes(Number(e.target.value))} />

        <label>Episode Number</label>
        <input value={episodeNumber} onChange={e => setEpisodeNumber(e.target.value)} />

        <label>Episode Title</label>
        <input value={episodeTitle} onChange={e => setEpisodeTitle(e.target.value)} />

        <label>Business Name</label>
        <input value={business} onChange={e => setBusiness(e.target.value)} />

        <label>Location</label>
        <input value={location} onChange={e => setLocation(e.target.value)} />

        <label>Contact</label>
        <input value={contact} onChange={e => setContact(e.target.value)} />

        <label>Promotion</label>
        <input value={promotion} onChange={e => setPromotion(e.target.value)} />

        <div className="buttonRow">
          <button onClick={() => setRunning(true)}>Start</button>
          <button onClick={() => setRunning(false)}>Pause</button>
          <button onClick={resetCountdown}>Reset</button>
          <button onClick={renderCountdown}>Render MP4</button>
        </div>

        <section className="visibility">
          <h2>Visibility</h2>
          {allVisibleKeys.map(key => (
            <button key={key} className={visible[key] ? 'active' : ''} onClick={() => toggle(key)}>
              {visible[key] ? 'On' : 'Off'} — {key}
            </button>
          ))}
        </section>
      </aside>

      <section className="preview" style={{ ['--accent' as string]: project.primaryColor }}>
        <div className="topBar" />
        <div className="bottomBar" />

        <div className="centerStack">
          <div className="series">{project.label}</div>
          {visible.episodeLine && <div className="episode">Episode {episodeNumber} • {episodeTitle}</div>}
          {visible.timer && <div className="timer">{formatClock(remaining)}</div>}
          {visible.status && <div className="status">{running ? 'Starting Soon' : 'Ready'}</div>}
        </div>

        {visible.progress && (
          <div className="progress"><div style={{ width: `${progress}%` }} /></div>
        )}

        {visible.partner && (
          <section className="partner">
            <h2>Featured Community Partner</h2>
            {visible.partnerFields && (
              <>
                <p><b>Business Name</b><br />{business}</p>
                <p><b>Location</b><br />{location}</p>
                <p><b>Contact Information</b><br />{contact}</p>
                <p><b>Community Partner Promotion</b><br />{promotion}</p>
              </>
            )}
            {visible.grantBadge && <div className="grantBadge">✓ Community Grant Fund Supported</div>}
          </section>
        )}

        {visible.qr && (
          <aside className="qr">
            <div>Learn More</div>
            <div className="qrBox">EPIC<br />Communities<br />QR</div>
          </aside>
        )}

        {visible.branding && <div className="branding">{project.shortLabel}</div>}
      </section>
    </main>
  );
}
