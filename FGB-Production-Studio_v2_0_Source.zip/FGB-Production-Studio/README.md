# FGB Production Studio

Desktop production application for:

- Football's Greatest Bears
- Football's Greatest Bars
- EPIC Communities

## Status

Version 2.0 starter codebase.

This repo replaces the prototype HTML/ZIP workflow with a real Electron + React + TypeScript application.

## Core capabilities in this starter

- Project switcher
- Preset system
- Visibility controls
- Countdown preview
- Episode fields
- Community Partner fields
- EPIC Communities language
- Render MP4 hook prepared for desktop packaging

## Install

```bash
npm install
```

## Run

```bash
npm run dev
```

## Package for Windows

```bash
npm run package:win
```

## Naming standard

EPIC Nexus has been renamed to **EPIC Communities**. Use EPIC Communities in future application, Community Partner, and production language.

## Next build step

Implement bundled FFmpeg rendering so the `Render MP4` button creates a finished video directly.
