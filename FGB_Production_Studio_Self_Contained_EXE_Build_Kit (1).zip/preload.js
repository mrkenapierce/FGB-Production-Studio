const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('fgbStudio', {
  renderCountdown: (payload) => ipcRenderer.invoke('render-countdown', payload)
});