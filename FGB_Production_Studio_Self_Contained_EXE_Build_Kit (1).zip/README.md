# FGB Production Studio

Self-contained Windows desktop production studio for:

- Football's Greatest Bears
- Football's Greatest Bars
- EPIC Communities

## What this builds

A portable Windows `.exe` with:

- working project switcher
- working presets
- working visibility controls
- countdown timer
- EPIC Communities QR active by default
- branding active by default
- Render MP4 button
- bundled FFmpeg via `ffmpeg-static`

## How to create the EXE

1. Push this repository to GitHub.
2. Open the repository on GitHub.
3. Click **Actions**.
4. Click **Build Windows EXE**.
5. Click **Run workflow**.
6. Wait for it to finish.
7. Download the artifact named **FGB-Production-Studio-Windows-EXE**.
8. Extract it and double-click the `.exe`.

## Local development

```bash
npm install
npm start
```

## Naming standard

EPIC Nexus is now **EPIC Communities**.