const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let ffmpegPath = require('ffmpeg-static');
if (app.isPackaged && ffmpegPath.includes('app.asar')) {
  ffmpegPath = ffmpegPath.replace('app.asar', 'app.asar.unpacked');
}

function escDrawText(value) {
  return String(value || '')
    .replace(/\\/g, '\\\\')
    .replace(/:/g, '\\:')
    .replace(/'/g, '')
    .replace(/\[/g, '')
    .replace(/\]/g, '')
    .slice(0, 120);
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    backgroundColor: '#031226',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(createWindow);

ipcMain.handle('render-countdown', async (_event, payload) => {
  const project = payload.project || 'fgb';
  const shortLabel = project === 'fgbars' ? 'FGBars' : project === 'epic' ? 'EPIC' : 'FGB';
  const series = project === 'fgbars'
    ? 'FOOTBALLS GREATEST BARS'
    : project === 'epic'
      ? 'EPIC COMMUNITIES'
      : 'FOOTBALLS GREATEST BEARS';
  const minutes = Math.max(1, Math.min(120, Number(payload.minutes || 15)));
  const duration = minutes * 60;
  const episode = escDrawText(payload.episode || '001');
  const title = escDrawText(payload.title || 'Episode Title');
  const defaultName = `${shortLabel}_Ep${episode}_Countdown.mp4`;

  const save = await dialog.showSaveDialog({
    title: 'Save Countdown MP4',
    defaultPath: defaultName,
    filters: [{ name: 'MP4 Video', extensions: ['mp4'] }]
  });

  if (save.canceled || !save.filePath) return { ok: false, canceled: true };

  const font = process.platform === 'win32'
    ? 'C\\:/Windows/Fonts/arialbd.ttf'
    : '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';

  const timerExpr = `%{eif\\:floor((${duration}-t)/60)\\:d\\:2}\\:%{eif\\:mod((${duration}-t)\\,60)\\:d\\:2}`;
  const vf = [
    'drawbox=x=0:y=0:w=iw:h=18:color=0xf15a24:t=fill',
    'drawbox=x=0:y=ih-18:w=iw:h=18:color=0xf15a24:t=fill',
    `drawtext=fontfile='${font}':text='${series}':fontcolor=white:fontsize=56:x=(w-text_w)/2:y=80`,
    `drawtext=fontfile='${font}':text='EPISODE ${episode} - ${title}':fontcolor=0xf15a24:fontsize=30:x=(w-text_w)/2:y=150`,
    `drawtext=fontfile='${font}':text='${timerExpr}':fontcolor=white:fontsize=148:x=(w-text_w)/2:y=250:shadowcolor=black@0.7:shadowx=4:shadowy=4`,
    `drawtext=fontfile='${font}':text='STARTING SOON':fontcolor=0xbec8d4:fontsize=30:x=(w-text_w)/2:y=455`,
    `drawtext=fontfile='${font}':text='${shortLabel}':fontcolor=0xf15a24:fontsize=28:x=w-text_w-55:y=h-60`
  ].join(',');

  const args = [
    '-y',
    '-f', 'lavfi',
    '-i', `color=c=0x031226:s=1280x720:d=${duration + 1}:r=1`,
    '-vf', vf,
    '-c:v', 'libx264',
    '-preset', 'ultrafast',
    '-pix_fmt', 'yuv420p',
    '-r', '1',
    save.filePath
  ];

  return await new Promise((resolve) => {
    const child = spawn(ffmpegPath, args);
    let stderr = '';
    child.stderr.on('data', d => stderr += d.toString());
    child.on('error', err => resolve({ ok: false, error: err.message }));
    child.on('close', code => {
      resolve({ ok: code === 0, code, path: save.filePath, error: code === 0 ? null : stderr.slice(-2000) });
    });
  });
});